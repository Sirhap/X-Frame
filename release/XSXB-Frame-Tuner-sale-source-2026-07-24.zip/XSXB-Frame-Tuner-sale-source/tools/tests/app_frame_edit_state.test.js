"use strict";

const assert = require("node:assert/strict");
const test = require("node:test");
const { createController } = require("../animation_tuner/public/app_frame_edit_state");

/** Creates the minimal frame-edit state fixture used by focused tests. */
function createFixture() {
  const group = { uiId: "group-1", frames: [{ width: 10, height: 20 }] };
  const transformOverrides = { 0: { visual_size: 2, offset: { x: 3, y: 4 }, rotation: 5 } };
  const boxOverrides = { 0: { hitbox: { enabled: true } } };
  const elements = {
    frameAudioName: { textContent: "", title: "" },
    frameAudioDrop: { classList: { toggle() {} }, setAttribute() {} },
    clearFrameAudio: { disabled: false },
  };
  return { group, transformOverrides, boxOverrides, elements };
}

test("frame edit state preserves transforms, box overrides, source geometry, and audio UI", () => {
  const { group, transformOverrides, boxOverrides, elements } = createFixture();
  let dirtyCount = 0;
  let binding = { name: "slash.wav" };
  const controller = createController({
    boxNames: ["hitbox", "hurtbox"],
    getConfig: () => ({ groups: [group] }),
    getCurrentGroup: () => group,
    getImages: () => [{ width: 12, height: 24 }],
    getFrameAudioBinding: () => binding,
    baseTransform: () => ({ scale: 1, scaleX: 1, scaleY: 1, offset: { x: 0, y: 0 }, rotation: 0 }),
    overrideStore: () => transformOverrides,
    boxOverrideStore: () => boxOverrides,
    frameBox: () => ({ offset: { x: 1, y: 2 }, size: { x: 3, y: 4 }, rotation: 6 }),
    tuningFrameKey: (index) => String(index),
    groupOwnsFrameKey: () => true,
    normalizeFrameBox: (_name, box) => ({ ...box, normalized: true }),
    opaqueRectForImage: () => ({ x: 2, y: 3, width: 4, height: 5 }),
    markDirty: () => {
      dirtyCount += 1;
    },
    elements,
    translate: (key, vars = {}) => (key === "frameSfx" ? `${key}:${vars.name}` : key),
  });

  assert.deepEqual(controller.frameTransform(0), {
    scale: 2,
    scaleX: 2,
    scaleY: 2,
    offset: { x: 3, y: 4 },
    rotation: 5,
  });
  controller.setFrameTransform(0, { scale: 3, scaleX: 4, scaleY: 2, offset: { x: 5, y: 6 } });
  assert.deepEqual(transformOverrides["0"], {
    visual_size: 3,
    visual_scale: { x: 4, y: 2 },
    offset: { x: 5, y: 6 },
    rotation: 5,
  });

  assert.deepEqual(controller.sourceFrameSize(0), { width: 12, height: 24 });
  assert.deepEqual(controller.sourceRectForBox(0), { x: 2, y: 3, width: 4, height: 5 });
  assert.deepEqual(controller.sourceBodyCenterForBox(0), {
    x: -2,
    y: -18.5,
    rect: { x: 2, y: 3, width: 4, height: 5 },
  });

  controller.setBoxOverride("hitbox", { enabled: false }, 0, group);
  assert.equal(boxOverrides["0"].hitbox.normalized, true);
  controller.deleteBoxOnFrame("hurtbox", 0, group);
  assert.equal(boxOverrides["0"].hurtbox.enabled, false);
  controller.syncFrameAudioInputs();
  assert.equal(elements.frameAudioName.textContent, "frameSfx:slash.wav");
  assert.equal(elements.clearFrameAudio.disabled, false);

  binding = null;
  controller.syncFrameAudioInputs();
  assert.equal(elements.frameAudioName.textContent, "noFrameSfx");
  assert.equal(elements.clearFrameAudio.disabled, true);
  transformOverrides["0"] = { visual_size: 1, offset: { x: 0, y: 0 }, rotation: 0 };
  controller.pruneNoopFrameOverrides();
  assert.deepEqual(transformOverrides, {});
  assert.equal(dirtyCount, 3);
});
