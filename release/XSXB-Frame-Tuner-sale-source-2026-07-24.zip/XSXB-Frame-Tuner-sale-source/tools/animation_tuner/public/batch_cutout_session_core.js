(function attachBatchCutoutSessionCore(root, factory) {
  "use strict";

  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  root.BatchCutoutSessionCore = api;
})(typeof globalThis !== "undefined" ? globalThis : this, () => {
  "use strict";

  const NUMERIC_CONTROLS = Object.freeze([
    ["cutoutTolerance", "cutoutToleranceValue", "tolerance"],
    ["cutoutFeather", "cutoutFeatherValue", "feather"],
    ["cutoutAlphaThreshold", "cutoutAlphaValue", "alphaThreshold"],
    ["cutoutChromaFeather", "cutoutChromaFeatherValue", "chromaFeather"],
    ["cutoutEdgeBoost", "cutoutEdgeBoostValue", "edgeBoost"],
    ["cutoutBlendStrength", "cutoutBlendStrengthValue", "blendStrength"],
    ["cutoutAlphaLow", "cutoutAlphaLowValue", "alphaLow"],
    ["cutoutAlphaHigh", "cutoutAlphaHighValue", "alphaHigh"],
    ["cutoutDespillStrength", "cutoutDespillStrengthValue", "despillStrength"],
    ["cutoutEdgeDespillRadius", "cutoutEdgeDespillRadiusValue", "edgeDespillRadius"],
    ["cutoutEdgeRecoveryStrength", "cutoutEdgeRecoveryStrengthValue", "edgeRecoveryStrength"],
    ["cutoutBackgroundRadius", "cutoutBackgroundRadiusValue", "backgroundRadius"],
    ["cutoutBlurRadius", "cutoutBlurRadiusValue", "blurRadius"],
    ["cutoutProtectionTolerance", "cutoutProtectionToleranceValue", "protectionTolerance"],
  ]);
  const PROPAGATION_FIELDS = Object.freeze([
    "repairs",
    "undoneRepairs",
    "protectedColors",
    "backgroundSamples",
    "seedPoints",
    "processingParameters",
    "processingActivated",
    "automaticCutoutActivated",
    "pendingAutomaticPropagation",
  ]);
  const MAX_EDIT_HISTORY = 100;

  /**
   * Clones logical session values without copying Canvas or ImageData instances.
   * @param {*} value Serializable repair or parameter value.
   * @returns {*} Independent clone.
   */
  function cloneSessionValue(value) {
    if (Array.isArray(value)) return value.map(cloneSessionValue);
    if (ArrayBuffer.isView(value)) return value.slice();
    if (!value || typeof value !== "object") return value;
    return Object.fromEntries(Object.entries(value).map(([key, entry]) => [key, cloneSessionValue(entry)]));
  }

  /**
   * Captures logical item state for a reversible apply-to-all transaction.
   * @param {object[]} items Session items.
   * @returns {Array<{item:object,state:object}>} In-memory transaction snapshot.
   */
  function captureItems(items) {
    return Array.from(items || []).map((item) => ({
      item,
      state: Object.fromEntries(PROPAGATION_FIELDS.map((field) => [field, cloneSessionValue(item[field])])),
    }));
  }

  /**
   * Restores a transaction snapshot and invalidates every restored result.
   * @param {Array<{item:object,state:object}>} snapshot Transaction snapshot.
   * @returns {void}
   */
  function restoreItems(snapshot) {
    for (const entry of snapshot || []) {
      for (const field of PROPAGATION_FIELDS) {
        entry.item[field] = cloneSessionValue(entry.state[field]);
      }
      resetItemProcessing(entry.item);
    }
  }

  /**
   * Captures one image's complete user-editable state.
   * @param {object} item Cutout session item.
   * @returns {object} Independent logical snapshot.
   */
  function captureItemState(item) {
    return Object.fromEntries(PROPAGATION_FIELDS.map((field) => [field, cloneSessionValue(item?.[field])]));
  }

  /**
   * Restores one image's complete user-editable state and invalidates derived pixels.
   * @param {object} item Cutout session item.
   * @param {object} snapshot Previously captured logical state.
   * @returns {void}
   */
  function restoreItemState(item, snapshot) {
    if (!item || !snapshot) return;
    for (const field of PROPAGATION_FIELDS) item[field] = cloneSessionValue(snapshot[field]);
    resetItemProcessing(item);
  }

  /**
   * Starts one reversible user edit and clears the stale redo branch.
   * @param {object} item Cutout session item.
   * @returns {void}
   */
  function recordItemEdit(item) {
    if (!item) return;
    if (!Array.isArray(item.editUndo)) item.editUndo = [];
    item.editUndo.push(captureItemState(item));
    if (item.editUndo.length > MAX_EDIT_HISTORY) item.editUndo.shift();
    item.editRedo = [];
  }

  /**
   * Ensures the DOM adapter exposes every required processing control.
   * @param {object} elements Cutout DOM adapter.
   * @returns {void}
   * @throws {TypeError} When a required control is missing.
   */
  function assertControls(elements) {
    const required = [
      "cutoutColor",
      "cutoutConnected",
      "cutoutPerceptual",
      "cutoutDespillMode",
      ...NUMERIC_CONTROLS.flatMap(([inputKey, outputKey]) => [inputKey, outputKey]),
    ];
    const missing = required.filter((key) => !elements?.[key]);
    if (missing.length) throw new TypeError(`Missing cutout controls: ${missing.join(", ")}`);
  }

  /**
   * Captures automatic-cutout controls as a serializable per-image snapshot.
   * @param {object} elements Cutout DOM adapter.
   * @returns {object} Normalized processing parameters.
   */
  function captureProcessingParameters(elements) {
    assertControls(elements);
    const parameters = {
      backgroundColor: String(elements.cutoutColor.value || "#ffffff"),
      connected: Boolean(elements.cutoutConnected.checked),
      perceptual: Boolean(elements.cutoutPerceptual.checked),
      despillMode: String(elements.cutoutDespillMode.value || "general"),
    };
    for (const [inputKey, , parameterKey] of NUMERIC_CONTROLS) {
      parameters[parameterKey] = Number(elements[inputKey].value);
    }
    return parameters;
  }

  /**
   * Restores a processing snapshot through the DOM adapter without emitting input events.
   * @param {object} elements Cutout DOM adapter.
   * @param {object|null|undefined} parameters Stored processing parameters.
   * @param {{syncNumericRange?:(input:object,output:object)=>void,onApplied?:()=>void}} [adapter] UI synchronization adapter.
   * @returns {void}
   */
  function applyProcessingParameters(elements, parameters, adapter = {}) {
    if (!parameters) return;
    assertControls(elements);
    elements.cutoutColor.value = String(parameters.backgroundColor || "#ffffff");
    elements.cutoutConnected.checked = Boolean(parameters.connected);
    elements.cutoutPerceptual.checked = Boolean(parameters.perceptual);
    elements.cutoutDespillMode.value = String(parameters.despillMode || "general");
    for (const [inputKey, outputKey, parameterKey] of NUMERIC_CONTROLS) {
      const value = Number(parameters[parameterKey]);
      if (Number.isFinite(value)) elements[inputKey].value = String(value);
      adapter.syncNumericRange?.(elements[inputKey], elements[outputKey]);
    }
    adapter.onApplied?.();
  }

  /**
   * Creates normalized worker options from one item's processing snapshot.
   * @param {object} item Queue item.
   * @param {{backgroundColor:object,backgroundColors:object[],protectedColors:object[]}} palettes Resolved per-image colors.
   * @returns {object} Worker processing options.
   */
  function createProcessingOptions(item, palettes) {
    const parameters = item?.processingParameters;
    if (!parameters) throw new TypeError("Cutout item has no processing parameter snapshot.");
    return {
      backgroundColor: palettes.backgroundColor,
      backgroundColors: palettes.backgroundColors,
      tolerance: parameters.tolerance,
      feather: parameters.feather,
      alphaThreshold: parameters.alphaThreshold,
      connected: parameters.connected,
      perceptual: parameters.perceptual,
      referenceChromaKey: !parameters.perceptual,
      chromaFeather: parameters.chromaFeather,
      seedPoints: item.seedPoints || [],
      edgeBoost: parameters.edgeBoost,
      blendStrength: parameters.blendStrength,
      alphaLow: Math.min(parameters.alphaLow, parameters.alphaHigh),
      alphaHigh: Math.max(parameters.alphaLow, parameters.alphaHigh),
      despillStrength: parameters.despillStrength,
      despillMode: parameters.despillMode,
      edgeDespillRadius: parameters.edgeDespillRadius,
      edgeRecoveryStrength: parameters.edgeRecoveryStrength,
      edgeRecoveryTolerance: 0,
      backgroundRadius: parameters.backgroundRadius,
      blurRadius: parameters.blurRadius,
      protectedColors: palettes.protectedColors,
      protectionTolerance: parameters.protectionTolerance,
      automaticCutout: Boolean(item.automaticCutoutActivated),
    };
  }

  /**
   * Clears one item's derived processing caches while retaining source data and edits.
   * @param {object|null} item Queue item.
   * @returns {void}
   */
  function resetItemProcessing(item) {
    if (!item) return;
    item.processingRevision = Number(item.processingRevision || 0) + 1;
    item.processingPromise = null;
    item.status = "ready";
    item.error = "";
    item.resultCanvas = null;
    item.resultImageData = null;
    item.resultThumbnail = "";
    item.thumbnailRevision = -1;
    item.qualityMetrics = null;
    item.quality = null;
    item.diagnosticCanvases = {};
  }

  /**
   * Finds the nearest target pixel that still matches one propagated background color.
   * Color distance is evaluated before spatial distance so a moved sprite cannot leave
   * the mapped seed on foreground pixels and silently produce an empty connected mask.
   * @param {{width:number,height:number,data:ArrayLike<number>}|null} imageData Target source pixels.
   * @param {{r:number,g:number,b:number}|null} color Propagated background sample.
   * @param {{x:number,y:number}} predictedPoint Canvas-scaled source position.
   * @param {number} tolerance Maximum normalized RGB distance accepted as background.
   * @returns {{x:number,y:number}|null} Reacquired target seed, or null when no color match exists.
   */
  function reacquireAutomaticSeed(imageData, color, predictedPoint, tolerance) {
    const width = Math.trunc(Number(imageData?.width));
    const height = Math.trunc(Number(imageData?.height));
    if (!imageData?.data || width <= 0 || height <= 0 || !color) return null;
    const maximumColorDistance = Math.max(0, Number(tolerance) || 0);
    let bestPoint = null;
    let bestColorDistance = Number.POSITIVE_INFINITY;
    let bestSpatialDistance = Number.POSITIVE_INFINITY;
    for (let index = 0; index < width * height; index += 1) {
      const offset = index * 4;
      if ((imageData.data[offset + 3] || 0) === 0) continue;
      const redDelta = Number(imageData.data[offset]) - Number(color.r);
      const greenDelta = Number(imageData.data[offset + 1]) - Number(color.g);
      const blueDelta = Number(imageData.data[offset + 2]) - Number(color.b);
      const colorDistance = (Math.hypot(redDelta, greenDelta, blueDelta) / Math.sqrt(3 * 255 * 255)) * 100;
      if (colorDistance > maximumColorDistance) continue;
      const x = index % width;
      const y = Math.floor(index / width);
      const spatialDistance = (x - predictedPoint.x) ** 2 + (y - predictedPoint.y) ** 2;
      if (
        colorDistance < bestColorDistance ||
        (colorDistance === bestColorDistance && spatialDistance < bestSpatialDistance)
      ) {
        bestColorDistance = colorDistance;
        bestSpatialDistance = spatialDistance;
        bestPoint = { x, y };
      }
    }
    return bestPoint;
  }

  /**
   * Reacquires source background seed points in a target image's canvas space.
   * @param {object} sourceItem Source session item.
   * @param {object} targetItem Target session item.
   * @returns {Array<{x:number,y:number}>} Independent target-space seed points.
   */
  function mapAutomaticSeedPoints(sourceItem, targetItem) {
    const sourceWidth = Number(sourceItem?.sourceImageData?.width || sourceItem?.sourceCanvas?.width);
    const sourceHeight = Number(sourceItem?.sourceImageData?.height || sourceItem?.sourceCanvas?.height);
    const targetWidth = Number(targetItem?.sourceImageData?.width || targetItem?.sourceCanvas?.width);
    const targetHeight = Number(targetItem?.sourceImageData?.height || targetItem?.sourceCanvas?.height);
    if (
      sourceWidth <= 0 ||
      sourceHeight <= 0 ||
      targetWidth <= 0 ||
      targetHeight <= 0 ||
      !Array.isArray(sourceItem?.seedPoints)
    )
      return [];
    const tolerance = Math.max(
      1,
      Number(sourceItem.processingParameters?.tolerance || 0) +
        Number(sourceItem.processingParameters?.edgeBoost || 0) * 0.12,
    );
    return sourceItem.seedPoints.flatMap((point, index) => {
      if (!Number.isFinite(point?.x) || !Number.isFinite(point?.y)) return [];
      const predictedPoint = {
        x: Math.max(0, Math.min(targetWidth - 1, (point.x * targetWidth) / sourceWidth)),
        y: Math.max(0, Math.min(targetHeight - 1, (point.y * targetHeight) / sourceHeight)),
      };
      const targetPoint = reacquireAutomaticSeed(
        targetItem?.sourceImageData || null,
        sourceItem.backgroundSamples?.[index] || sourceItem.backgroundSamples?.[0] || null,
        predictedPoint,
        tolerance,
      );
      return [targetPoint || predictedPoint];
    });
  }

  /**
   * Samples target-frame background colors at propagated seed points.
   * Video decoding can shift a nominally solid background by a few RGB values
   * between frames, so retaining the source-frame colors would make a narrow
   * tolerance remove only the frame where the user sampled the background.
   *
   * @param {object} sourceItem Source session item.
   * @param {object} targetItem Target session item.
   * @param {Array<{x:number,y:number}>} seedPoints Mapped target-space seed points.
   * @returns {Array<{r:number,g:number,b:number,a:number}>} Per-target background colors.
   */
  function sampleMappedBackgroundColors(sourceItem, targetItem, seedPoints) {
    const sourceColors = Array.isArray(sourceItem?.backgroundSamples) ? sourceItem.backgroundSamples : [];
    const imageData = targetItem?.sourceImageData;
    const width = Math.trunc(Number(imageData?.width));
    const height = Math.trunc(Number(imageData?.height));
    if (!imageData?.data || width <= 0 || height <= 0 || !seedPoints.length) {
      return cloneSessionValue(sourceColors);
    }
    return sourceColors.map((sourceColor, index) => {
      const point = seedPoints[index];
      if (!Number.isFinite(point?.x) || !Number.isFinite(point?.y)) {
        return cloneSessionValue(sourceColor);
      }
      const x = Math.max(0, Math.min(width - 1, Math.round(point.x)));
      const y = Math.max(0, Math.min(height - 1, Math.round(point.y)));
      const offset = (y * width + x) * 4;
      const alpha = Number(imageData.data[offset + 3] || 0);
      if (!alpha) return cloneSessionValue(sourceColor);
      return {
        r: Number(imageData.data[offset]),
        g: Number(imageData.data[offset + 1]),
        b: Number(imageData.data[offset + 2]),
        a: alpha,
      };
    });
  }

  /**
   * Copies the complete automatic background-removal stage to one target item.
   * Local repairs are intentionally preserved so callers can compose automatic
   * processing with a subsequently propagated repair in the same transaction.
   * @param {object} targetItem Target session item.
   * @param {object} sourceItem Source session item.
   * @param {{mapSeedPoints?:boolean}} [options] Per-image propagation behavior.
   * @returns {void}
   */
  function copyAutomaticProcessingState(targetItem, sourceItem, options = {}) {
    if (!targetItem || !sourceItem?.processingParameters) {
      throw new TypeError("Automatic processing copy requires source parameters and a target item.");
    }
    targetItem.processingParameters = cloneSessionValue(sourceItem.processingParameters);
    targetItem.seedPoints = options.mapSeedPoints ? mapAutomaticSeedPoints(sourceItem, targetItem) : [];
    targetItem.backgroundSamples = options.mapSeedPoints
      ? sampleMappedBackgroundColors(sourceItem, targetItem, targetItem.seedPoints)
      : cloneSessionValue(sourceItem.backgroundSamples || []);
    targetItem.automaticCutoutActivated = true;
    targetItem.processingActivated = true;
    targetItem.pendingAutomaticPropagation = false;
    resetItemProcessing(targetItem);
  }

  /**
   * Copies one source image's automatic-cutout settings to every session item.
   * Manual FramePacker reference colors are copied to every target image.
   * @param {object[]} items Session items.
   * @param {object} sourceItem Selected source item.
   * @param {{publishedCanvases?:object[],mapSeedPoints?:boolean}} [options] Transaction and per-image seed behavior.
   * @returns {number} Number of updated items.
   */
  function propagateAutomaticProcessing(items, sourceItem, options = {}) {
    if (!sourceItem?.processingParameters) {
      throw new TypeError("Automatic propagation requires a source parameter snapshot.");
    }
    beginPropagation(items, sourceItem, options);
    for (const item of items || []) {
      copyAutomaticProcessingState(item, sourceItem, options);
    }
    return Array.isArray(items) ? items.length : 0;
  }

  /**
   * Starts a reversible apply-to-all transaction on the source item.
   * @param {object[]} items Session items.
   * @param {object} sourceItem Selected source item.
   * @param {{publishedCanvases?:object[]}} [options] Host canvases visible before propagation.
   * @returns {void}
   */
  function beginPropagation(items, sourceItem, options = {}) {
    if (!sourceItem) throw new TypeError("Propagation requires a source item.");
    sourceItem.propagationUndo = {
      snapshot: captureItems(items),
      repairCount: sourceItem.repairs?.length || 0,
      editUndoCount: sourceItem.editUndo?.length || 0,
      publishedCanvases: Array.isArray(options.publishedCanvases)
        ? Array.from(options.publishedCanvases)
        : null,
    };
    sourceItem.propagationRedo = null;
  }

  /**
   * Restores the state preceding the latest apply-to-all transaction.
   * @param {object[]} items Session items.
   * @param {object} sourceItem Selected source item.
   * @returns {boolean} Whether a transaction was restored.
   */
  function undoPropagation(items, sourceItem) {
    const transaction = sourceItem?.propagationUndo;
    const hasNewerRepair = (sourceItem?.repairs?.length || 0) > transaction?.repairCount;
    const hasNewerItemEdit = (sourceItem?.editUndo?.length || 0) > transaction?.editUndoCount;
    if (!transaction || hasNewerRepair || hasNewerItemEdit) return false;
    const redoSnapshot = captureItems(items);
    const redoPublishedCanvases = Array.from(items || [], (item) => item.publishedCanvas || null);
    restoreItems(transaction.snapshot);
    sourceItem.propagationUndo = null;
    sourceItem.propagationRedo = {
      snapshot: redoSnapshot,
      publishedCanvases: redoPublishedCanvases,
    };
    return true;
  }

  /**
   * Reapplies the most recently undone apply-to-all transaction.
   * @param {object[]} items Session items.
   * @param {object} sourceItem Selected source item.
   * @returns {boolean} Whether a transaction was reapplied.
   */
  function redoPropagation(items, sourceItem) {
    const transaction = sourceItem?.propagationRedo;
    if (!transaction) return false;
    const undoSnapshot = captureItems(items);
    restoreItems(transaction.snapshot);
    sourceItem.propagationUndo = {
      snapshot: undoSnapshot,
      repairCount: sourceItem.repairs?.length || 0,
      editUndoCount: sourceItem.editUndo?.length || 0,
      publishedCanvases: Array.from(items || [], (item) => item.publishedCanvas || null),
    };
    sourceItem.propagationRedo = null;
    return true;
  }

  /**
   * Undoes the latest local edit or apply-to-all transaction in user-visible order.
   * @param {object[]} items Session items.
   * @param {object} sourceItem Selected source item.
   * @returns {{changed:boolean,live:boolean}} Undo result and live-publish requirement.
   */
  function undoEdit(items, sourceItem) {
    const publishedCanvases = sourceItem?.propagationUndo?.publishedCanvases;
    if (undoPropagation(items, sourceItem)) {
      return {
        changed: true,
        live: true,
        ...(publishedCanvases ? { publishedCanvases } : {}),
      };
    }
    const snapshot = sourceItem?.editUndo?.pop();
    if (snapshot) {
      if (!Array.isArray(sourceItem.editRedo)) sourceItem.editRedo = [];
      sourceItem.editRedo.push(captureItemState(sourceItem));
      restoreItemState(sourceItem, snapshot);
      return { changed: true, live: false };
    }
    const repair = sourceItem?.repairs?.pop();
    if (!repair) return { changed: false, live: false };
    sourceItem.undoneRepairs.push(repair);
    resetItemProcessing(sourceItem);
    return { changed: true, live: Boolean(sourceItem.propagationRedo) };
  }

  /**
   * Redoes local edits before reapplying a later apply-to-all transaction.
   * @param {object[]} items Session items.
   * @param {object} sourceItem Selected source item.
   * @returns {{changed:boolean,live:boolean}} Redo result and live-publish requirement.
   */
  function redoEdit(items, sourceItem) {
    const snapshot = sourceItem?.editRedo?.pop();
    if (snapshot) {
      if (!Array.isArray(sourceItem.editUndo)) sourceItem.editUndo = [];
      sourceItem.editUndo.push(captureItemState(sourceItem));
      restoreItemState(sourceItem, snapshot);
      return { changed: true, live: false };
    }
    const repair = sourceItem?.undoneRepairs?.pop();
    if (repair) {
      sourceItem.repairs.push(repair);
      resetItemProcessing(sourceItem);
      return { changed: true, live: Boolean(sourceItem.propagationRedo) };
    }
    const publishedCanvases = sourceItem?.propagationRedo?.publishedCanvases;
    if (!redoPropagation(items, sourceItem)) return { changed: false, live: false };
    return {
      changed: true,
      live: true,
      ...(publishedCanvases ? { publishedCanvases } : {}),
    };
  }

  return Object.freeze({
    applyProcessingParameters,
    beginPropagation,
    captureProcessingParameters,
    copyAutomaticProcessingState,
    createProcessingOptions,
    recordItemEdit,
    propagateAutomaticProcessing,
    redoEdit,
    redoPropagation,
    resetItemProcessing,
    undoEdit,
    undoPropagation,
  });
});
