(function attachBatchCutoutSessionController(root, factory) {
  "use strict";

  const api = factory(root);
  if (typeof module === "object" && module.exports) module.exports = api;
  if (root) root.BatchCutoutSessionController = api;
})(typeof globalThis !== "undefined" ? globalThis : this, (root) => {
  "use strict";

  /**
   * Creates the modal and isolated-workset session controller.
   * @param {object} dependencies Modal/session dependencies supplied by the host.
   * @returns {{clear:Function,deleteSelectedItems:Function,open:Function,openWorkset:Function,close:Function,requestClose:Function,hasWorksetChanges:Function}}
   */
  function createController(dependencies = {}) {
    const {
      state,
      elements,
      text,
      documentRef = root?.document,
      host = {},
      setRepairMode,
      setEditorInert,
      renderLanguage,
      renderPreview,
      scheduleBatchThumbnails,
      stopBatchPlayback,
      cancelRepairGestureFrame,
      resolveConfirmation,
      resultArtifacts,
      assertImagePixelBudget,
      createItem,
      applyProcessingParametersToControls,
      selectedItem,
      renderQueue,
      setStatus,
      requestConfirmation,
    } = dependencies;
    if (!state || !elements || typeof selectedItem !== "function" || typeof createItem !== "function") {
      throw new TypeError("BatchCutoutSessionController dependencies are required.");
    }
    const documentApi = documentRef;

    /**
     * Clears the current batch after an explicit confirmation.
     * @param {{mode?:"clear"|"new"}} [options] Confirmation wording variant.
     * @returns {Promise<boolean>} Whether the batch was cleared.
     */
    async function clear(options = {}) {
      const newBatch = options.mode === "new";
      if (!state.items.length) {
        setStatus(text("ready"));
        return true;
      }
      const confirmed = await requestConfirmation(text(newBatch ? "newBatchConfirm" : "clearConfirm"), [], {
        title: text(newBatch ? "newBatchTitle" : "clearTitle"),
        confirmLabel: text(newBatch ? "confirmNewBatch" : "confirmClear"),
        tone: "danger",
      });
      if (!confirmed) return false;
      stopBatchPlayback();
      state.thumbnailJob += 1;
      resultArtifacts.clear();
      state.items = [];
      state.sourceKind = "";
      state.selectedIndex = 0;
      state.selectedIds.clear();
      state.selectionAnchorIndex = 0;
      state.samplingProtectedColor = false;
      state.samplingBackgroundColor = false;
      state.protectionPreview = null;
      state.previewScale = null;
      state.previewFitScale = null;
      state.previewPanX = 0;
      state.previewPanY = 0;
      state.cancelRequested = false;
      state.batchTrayCollapsed = true;
      state.previewMode = "result";
      state.qualityOnly = false;
      renderQueue();
      renderPreview();
      setStatus(text("ready"));
      return true;
    }

    /**
     * Removes selected batch items after explicit confirmation.
     * @returns {Promise<void>}
     */
    async function deleteSelectedItems() {
      const selectedCount = state.selectedIds.size;
      if (!selectedCount) return;
      const confirmed = await requestConfirmation(text("deleteConfirm", { count: selectedCount }), [], {
        title: text("deleteTitle"),
        confirmLabel: text("confirmDelete"),
        tone: "danger",
      });
      if (!confirmed) return;
      stopBatchPlayback();
      state.thumbnailJob += 1;
      const currentItemId = selectedItem()?.id;
      state.items = state.items.filter((item) => !state.selectedIds.has(item.id));
      state.selectedIds.clear();
      const preservedIndex = state.items.findIndex((item) => item.id === currentItemId);
      state.selectedIndex =
        preservedIndex >= 0
          ? preservedIndex
          : Math.min(state.selectedIndex, Math.max(0, state.items.length - 1));
      if (state.items[state.selectedIndex]) state.selectedIds.add(state.items[state.selectedIndex].id);
      state.selectionAnchorIndex = state.selectedIndex;
      renderQueue();
      renderPreview();
      scheduleBatchThumbnails();
    }

    /**
     * Opens the modal workbench.
     * @param {{syncRoute?:boolean}} [options] Route synchronization behavior.
     * @returns {void}
     */
    function open(options = {}) {
      if (state.sourceKind !== "workset") state.sessionMode = "batch";
      if (!state.items.length) {
        elements.cutoutConnected.checked = false;
        elements.cutoutPerceptual.checked = false;
        state.batchTrayCollapsed = true;
      } else if (state.sourceKind !== "workset") {
        setStatus(text("batchResumed", { count: state.items.length }), "idle");
      }
      state.returnFocus = documentApi.activeElement;
      elements.cutoutModal.hidden = false;
      setRepairMode("automatic");
      setEditorInert(true);
      documentApi.body.classList.add("cutoutOpen");
      if (options.syncRoute !== false) host.onOpen?.();
      renderLanguage();
      renderPreview();
      scheduleBatchThumbnails();
      elements.cutoutAddFiles.focus();
    }

    /**
     * Opens an isolated cutout session for an unsaved animation workset.
     * Applying resolves with processed outputs; closing resolves with null.
     * @param {{name?:string,mode?:"single"|"batch",selectedIndex?:number,onLiveApply?:(outputs:Array<object>)=>void,items:Array<{name?:string,image:CanvasImageSource,frame?:object}>}} workset Unsaved frame workset.
     * @returns {Promise<Array<object>|null>}
     */
    function openWorkset(workset) {
      if (state.busy) return Promise.reject(new Error("Batch cutout is busy."));
      const inputs = Array.isArray(workset?.items) ? workset.items : [];
      if (!inputs.length) return Promise.reject(new Error(text("invalidFiles")));
      if (inputs.length > 240) return Promise.reject(new Error(text("tooMany")));
      if (state.worksetResolver) {
        const previousResolver = state.worksetResolver;
        state.worksetResolver = null;
        previousResolver(null);
      }
      stopBatchPlayback();
      state.thumbnailJob += 1;
      elements.cutoutConnected.checked = false;
      elements.cutoutPerceptual.checked = false;
      state.batchTrayCollapsed = true;
      try {
        let retainedPixels = 0;
        state.items = inputs.map((item, index) => {
          const budget = assertImagePixelBudget(item.image, retainedPixels);
          retainedPixels = budget.totalPixels;
          return createItem(
            item.image,
            item.name || `frame_${String(index + 1).padStart(4, "0")}.png`,
            item.frame || null,
          );
        });
      } catch (error) {
        return Promise.reject(error);
      }
      state.sourceKind = "workset";
      state.sessionMode = workset.mode === "single" || inputs.length === 1 ? "single" : "batch";
      state.items.forEach((item) => {
        item.automaticCutoutActivated = false;
        item.processingActivated = false;
        item.pendingAutomaticPropagation = false;
      });
      state.worksetName = String(workset.name || "animation");
      state.selectedIndex = Math.max(0, Math.min(state.items.length - 1, Number(workset.selectedIndex) || 0));
      applyProcessingParametersToControls(selectedItem()?.processingParameters);
      state.selectedIds = new Set(
        state.items[state.selectedIndex] ? [state.items[state.selectedIndex].id] : [],
      );
      state.protectionPreview = null;
      state.selectionAnchorIndex = state.selectedIndex;
      state.previewScale = null;
      state.previewFitScale = null;
      state.previewPanX = 0;
      state.previewPanY = 0;
      state.cancelRequested = false;
      state.previewMode = state.sessionMode === "single" ? "original" : "result";
      state.qualityOnly = false;
      return new Promise((resolve) => {
        resolve.liveApply = typeof workset.onLiveApply === "function" ? workset.onLiveApply : null;
        state.worksetResolver = resolve;
        // A workset belongs to the organizer that created it. Keep the host
        // route and editor lifecycle intact instead of presenting the child
        // session as a standalone cutout workbench.
        open({ syncRoute: false });
        renderQueue();
        renderPreview();
        scheduleBatchThumbnails();
        setStatus(
          state.sessionMode === "single"
            ? text("singleLoaded")
            : text("worksetLoaded", { name: state.worksetName, count: state.items.length }),
          "success",
        );
      });
    }
    /**
     * Closes the modal workbench.
     * @param {Array<object>|null} worksetResult Optional processed workset outputs.
     * @param {{syncRoute?:boolean}} [options] Route synchronization behavior.
     * @returns {void}
     */
    function close(worksetResult = null, options = {}) {
      const embeddedWorkset = typeof state.worksetResolver === "function";
      stopBatchPlayback();
      cancelRepairGestureFrame();
      state.thumbnailJob += 1;
      if (!elements.cutoutConfirmPanel.hidden) resolveConfirmation(false);
      elements.cutoutModal.hidden = true;
      if (!embeddedWorkset) setEditorInert(false);
      documentApi.body.classList.remove("cutoutOpen");
      if (!embeddedWorkset && options.syncRoute !== false) host.onClose?.();
      state.previewSpacePan = false;
      state.previewPanDrag = null;
      elements.cutoutModal.classList.remove("isPreviewPanReady", "isPreviewPanning");
      const resolver = state.worksetResolver;
      state.worksetResolver = null;
      state.worksetName = "";
      if (resolver) {
        resultArtifacts.clear();
        state.items = [];
        state.sourceKind = "";
        state.selectedIndex = 0;
        state.selectedIds.clear();
        state.sessionMode = "batch";
        resolver(worksetResult);
      }
      if (state.returnFocus && typeof state.returnFocus.focus === "function") state.returnFocus.focus();
    }
    /**
     * Requests a safe workbench close and protects isolated workset edits.
     * @param {Array<object>|null} worksetResult Optional processed workset outputs.
     * @param {{syncRoute?:boolean,force?:boolean}} [options] Close behavior.
     * @returns {Promise<boolean>} Whether the workbench closed.
     */
    async function requestClose(worksetResult = null, options = {}) {
      const discardsWorkset =
        worksetResult === null && typeof state.worksetResolver === "function" && hasWorksetChanges();
      if (discardsWorkset && !options.force) {
        const confirmed = await requestConfirmation(text("discardConfirm"), [], {
          title: text("discardTitle"),
          confirmLabel: text("confirmDiscard"),
          tone: "danger",
        });
        if (!confirmed) return false;
      }
      close(worksetResult, options);
      return true;
    }

    /**
     * Returns whether an isolated workset has generated or edited output.
     * Merely opening a single image on its original view is not a modification.
     * @returns {boolean}
     */
    function hasWorksetChanges() {
      return state.items.some(
        (item) =>
          item.processingActivated ||
          item.repairs?.length ||
          item.backgroundSamples?.length ||
          item.protectedColors?.length,
      );
    }

    return { clear, deleteSelectedItems, open, openWorkset, close, requestClose, hasWorksetChanges };
  }

  return { createController };
});
